package princ;

import java.io.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sn = new Scanner(System.in);
		int opcion = 0;

		do {
			System.out.println("\n>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
			System.out.println("1. Cargad dades del CSV en la Base de Datos");
			System.out.println("2. Consulta SQL dels Llibres (t�tol, autor i any de publicaci�)\n   dels autors nascuts abans de 1950");
			System.out.println("3. Consulta SQL de les Editorials que hagen publicat almenys un\n   llibre en el segle XXI");
			System.out.println("4. Tancar");
			System.out.println("\nOpcio  : ");
			opcion = sn.nextInt();
			switch (opcion) {
			case 1:
				crearLlibre();
				break;
			case 2:

				// SELECT `titulo`, `autor`, `anyPublicacio` FROM `tabla1` WHERE `anyNaixement`
				// < 1950;

				String jdbcURL = "jdbc:mysql://localhost:3306/Biblioteca";
				String username = "root";
				String password = "";
				Connection connection = null;
				try {
					connection = DriverManager.getConnection(jdbcURL, username, password);
					connection.setAutoCommit(false);
				} catch (SQLException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}

				Statement stmt = null;
				try {
					stmt = connection.createStatement();
				} catch (SQLException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}
				ResultSet rs = null;
				try {
					rs = stmt.executeQuery(
							"SELECT  `titulo`, `autor`,  `anyPublicacio` FROM `tabla1` WHERE `anyNaixement` < 1950");
					while (rs.next()) {
						System.out.println(rs.getString(1) + " - " + rs.getString(2) + " - " + rs.getString(3));
					}
				} catch (SQLException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}

				// String sqlz = "SELECT `titulo`, `autor`, `anyPublicacio` FROM `tabla1` WHERE
				// `anyNaixement` < 1950";
				PreparedStatement statementz;

				try {
					statementz = connection.prepareStatement(String.valueOf(rs));
					statementz.addBatch();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

				try {
					statementz = connection.prepareStatement(String.valueOf(rs));
					statementz.executeBatch();
					statementz.executeBatch();
					connection.commit();
					connection.close();

				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				break;
			case 3:
				String jdbcURLX = "jdbc:mysql://localhost:3306/Biblioteca";
				String usernameX = "root";
				String passwordX = "";
				Connection connectionX = null;
				try {
					connectionX = DriverManager.getConnection(jdbcURLX, usernameX, passwordX);
					connectionX.setAutoCommit(false);
				} catch (SQLException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}

				Statement stmtX = null;
				try {
					stmtX = connectionX.createStatement();
				} catch (SQLException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}
				ResultSet rsX = null;
				try {
					rsX = stmtX.executeQuery(
							"SELECT  `editorial` FROM `tabla1` WHERE `anyPublicacio` > 2000");
					while (rsX.next()) {
						System.out.println(rsX.getString(1));
					}
				} catch (SQLException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}

				// String sqlz = "SELECT `titulo`, `autor`, `anyPublicacio` FROM `tabla1` WHERE
				// `anyNaixement` < 1950";
				PreparedStatement statementzX;

				try {
					statementzX = connectionX.prepareStatement(String.valueOf(rsX));
					statementzX.addBatch();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

				try {
					statementzX = connectionX.prepareStatement(String.valueOf(rsX));
					statementzX.executeBatch();
					statementzX.executeBatch();
					connectionX.commit();
					connectionX.close();

				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			default:
				System.out.println(".........FI.........");
				break;
			}

		} while (opcion != 4);
	}

	public static void crearLlibre() {
		String jdbcURL = "jdbc:mysql://localhost:3306/Biblioteca";
		String username = "root";
		String password = "";

		String csvFilePath = "AE04_T1_4_JDBC_Dades.csv";

		int batchSize = 20;

		Connection connection = null;

		try {

			connection = DriverManager.getConnection(jdbcURL, username, password);
			connection.setAutoCommit(false);

			String sql = "INSERT INTO `tabla1`(`titulo`, `autor`, `anyNaixement`, `anyPublicacio`, `editorial`, `numPagines`) "
					+ "VALUES (?, ?, ?, ?, ?, ?)";
			PreparedStatement statement = connection.prepareStatement(sql);

			BufferedReader lineReader = new BufferedReader(new FileReader(csvFilePath));
			String lineText = null;

			int count = 0;

			// nos saltamos la primera linea
			lineReader.readLine();

			while ((lineText = lineReader.readLine()) != null) {
				String[] data = lineText.split(";");
				String titulo = data[0];
				String autor = data[1];
				String anyNaixement = data[2];
				String anyPublicacio = data[3];
				String editorial = data[4];
				String numPagines = data[5];

				statement.setString(1, titulo);
				statement.setString(2, autor);
				statement.setString(3, anyNaixement);
				statement.setString(4, anyPublicacio);
				statement.setString(5, editorial);
				statement.setString(6, numPagines);

				statement.addBatch();

				if (count % batchSize == 0) {
					statement.executeBatch();
				}
			}

			lineReader.close();

			// execute the remaining queries
			statement.executeBatch();

			connection.commit();
			connection.close();

		} catch (IOException ex) {
			System.err.println(ex);
		} catch (SQLException ex) {
			ex.printStackTrace();

			try {
				connection.rollback();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}
