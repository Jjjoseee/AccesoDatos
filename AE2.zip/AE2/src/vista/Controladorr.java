package vista;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;





	public class Controladorr {
		private Modeloo modelo;
		private Vistaaa vista;
		private ActionListener actionListenerBoton1, actionListenerBoton2;
		
		Controladorr(Modeloo modelo, Vistaaa vista){
			this.modelo = modelo;
			this.vista = vista;
			control();
		}
		
		
		
		public void control() {
			String textOrig = modelo.leerFicheroTXT();
			vista.getTextAreaOriginal().setText(textOrig);
			
			actionListenerBoton1 = new ActionListener() {
				public void actionPerformed(ActionEvent e) {					
			
					String txt = modelo.buscarP(vista.getTextFieldBuscar().getText());					
					vista.getTextFieldBuscar().setText("La paraula apareix "+txt+" vegades.");
					
					
				}
			};
			vista.getBtnBuscar().addActionListener(actionListenerBoton1);
			
			actionListenerBoton2 = new ActionListener() {
				public void actionPerformed(ActionEvent e) {					
			
					String txt = modelo.remplazar(vista.getTextFieldBuscar().getText(), vista.getTextFieldReemplazar().getText());
					vista.getTextAreaModificado().setText(txt);
					
				}
			};
			vista.getBtnReemplazar().addActionListener(actionListenerBoton2);

			
			
		}
	}


