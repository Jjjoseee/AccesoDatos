package vista;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Modeloo {

	private String mensaje1;
	private String mensaje2;
	String t = "";

	Modeloo() {
		this.mensaje1 = "Mensaje 1";
		this.mensaje2 = "Mensaje 2";
	}

	public String getMensaje1() {
		return mensaje1;
	}

	public String getMensaje2() {
		return mensaje2;
	}

	public String leerFicheroTXT() {
		try {
			File file = new File(
					"AE02_T1_2_Streams_Groucho.txt");
			Scanner scn = new Scanner(file);
			while (scn.hasNextLine()) {
				t += scn.nextLine() + "\n";
			}
			scn.close();

		} catch (FileNotFoundException e) {
			System.out.println("An error ocurred.");
			e.printStackTrace();
		}
		return t;
	}

	public String buscarP(String txt) {

		File file = new File("AE02_T1_2_Streams_Groucho.txt");
		String[] words = null;
		FileReader fr = null;
		try {
			fr = new FileReader(file);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		BufferedReader br = new BufferedReader(fr);
		String s;

		int count = 0;
		try {
			while ((s = br.readLine()) != null) {
				words = s.split(" ");
				for (String word : words) {
					if (word.equals(txt)) {
						count++;
					}
				}
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (count != 0) {
			t += "The given word is present for " + count + " Times in the file";
		} else {
			t += "The given word is not present in the file";
		}

		try {
			fr.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return String.valueOf(count);
	}

	public String remplazar(String told, String tnew) {

		String nnn="";

		try {
			File file = new File("AE02_T1_2_Streams_Groucho.txt");

			BufferedReader reader = new BufferedReader(new FileReader(file));

			String line = "", oldtext = "";

			while ((line = reader.readLine()) != null) {

				oldtext += line + "\n";
			}
			reader.close();

			
			nnn = oldtext.replaceAll(told, tnew);
			FileWriter writer = null;
			writer = new FileWriter("AE02_T1_2_Streams_Groucho_Reemplazado.txt");
			writer.write(nnn);
			writer.close();
		} catch (IOException e) {
			// handle e
		}

		return nnn;

	}
}
