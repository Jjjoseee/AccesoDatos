package vista;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			Modeloo modelo = new Modeloo();
			Vistaaa vista = new Vistaaa();
			try {
				Controladorr controlador = new Controladorr(modelo, vista);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}

}
