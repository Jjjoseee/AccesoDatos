package princ;

import org.w3c.dom.*;
import org.xml.sax.SAXException;

import com.sun.net.httpserver.Authenticator.Result;

import javax.xml.parsers.*;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import java.io.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Scanner;

public class Biblioteca {

	static File file = new File("Llibre.xml");

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sn = new Scanner(System.in);
		int opcion = 0;

		do {
			System.out.println("\n########################################################################");
			System.out.println("1. Mostrar tots els t�tols de la biblioteca");
			System.out.println("2. Mostrar informaci� detallada d�un llibre");
			System.out.println("3. Crear nou llibre");
			System.out.println("4. Actualitzar llibre");
			System.out.println("5. Borrar llibre");
			System.out.println("6. Tanca la biblioteca");
			System.out.println("\nOpcio  : ");
			opcion = sn.nextInt();
			switch (opcion) {
			case 1:
				ArrayList<Llibre> llib = recuperarTots();
				for (Llibre x : llib) {
					System.out.println("Id: " + x.getIdentificador() + "\nTitol: " + x.getTitol() + "\nAutor: "
							+ x.getAutor() + "\nEditorial: " + x.getEditorial() + "\nAny de publicacio: "
							+ x.getAnyoPublicacion() + "\nNumero de pagines: " + x.getNumPagines());
					System.out.println("_______________________________\n");
				}
				break;
			case 2:

				// utilizamos recuperarLlibre para crear un llibre amb els datos que volem
				System.out.println("Identificador: ");
				String id = "";
				Scanner sc = new Scanner(System.in);
				id = sc.nextLine();
				Llibre x = recuperarLlibre(Integer.parseInt(id));

				// i el mostrem amb mostrarLlibre, que rep un objecte llibre
				mostrarLlibre(x);

				break;
			case 3:

				System.out.println("Id: " + contadorID());
				int idd = contadorID();
				System.out.println("Titol: ");
				String tit = "";
				Scanner entradaEscaner1 = new Scanner(System.in);
				tit = entradaEscaner1.nextLine();
				System.out.println("Autor: ");
				String aut = "";
				Scanner entradaEscaner2 = new Scanner(System.in);
				aut = entradaEscaner2.nextLine();
				System.out.println("Editorial: ");
				String edi = "";
				Scanner entradaEscaner3 = new Scanner(System.in);
				edi = entradaEscaner3.nextLine();
				System.out.println("Any de publicacio: ");
				String any = "";
				Scanner entradaEscaner4 = new Scanner(System.in);
				any = entradaEscaner4.nextLine();
				System.out.println("Numero de pagines: ");
				String num = "";
				Scanner entradaEscaner5 = new Scanner(System.in);
				num = entradaEscaner5.nextLine();

				Llibre objLlibre = new Llibre(idd, tit, aut, Integer.parseInt(any), edi, Integer.parseInt(num));
				System.out.println("Se ha creat automaticament amb la id: " + crearLlibre(objLlibre));

				break;
			case 4:
				System.out.println("Identificador del llibre a modificar: ");
				String idz = "";
				Scanner scz = new Scanner(System.in);
				idz = scz.nextLine();
				// Llibre xz = recuperarLlibre(Integer.parseInt(idz));
				actualitzaLlibre(Integer.parseInt(idz));

				break;
			case 5:
				System.out.println("Funcio no programada.");
				break;
			default:
				System.out.println(".........FI.........");
				break;
			}

		} while (opcion != 6);
	}

	public static ArrayList<Llibre> recuperarTots() {

		ArrayList<Llibre> llibreee = new ArrayList<Llibre>();

		try {
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document document = dBuilder.parse(new File("Llibre.xml"));
			// Element raiz = document.getDocumentElement();
			// System.out.println("Contenido XML " + raiz.getNodeName() + ":");
			System.out.println("\n");
			NodeList nodeList = document.getElementsByTagName("libro");
			for (int i = 0; i < nodeList.getLength(); i++) {
				Node node = nodeList.item(i);
				if (node.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) node;
					String idd = eElement.getAttribute("id");
					String tit = eElement.getElementsByTagName("titulo").item(0).getTextContent();
					String aut = eElement.getElementsByTagName("autor").item(0).getTextContent();
					String any = eElement.getElementsByTagName("anyoPubl").item(0).getTextContent();
					String edi = eElement.getElementsByTagName("editorial").item(0).getTextContent();
					String num = eElement.getElementsByTagName("numPagines").item(0).getTextContent();

					// creamos objeto libro
					Llibre objLlibre = new Llibre(Integer.parseInt(idd), tit, aut, Integer.parseInt(any), edi,
							Integer.parseInt(num));

					// lo metemos en la array
					llibreee.add(objLlibre);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return llibreee;

	}

	public static int contadorID() {
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder = null;
		try {
			dBuilder = dbFactory.newDocumentBuilder();
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Document document = null;
		try {
			document = dBuilder.parse(new File("Llibre.xml"));
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// Element raiz = document.getDocumentElement();
		NodeList nodeList = document.getElementsByTagName("libro");
		int cont = nodeList.getLength();
		return cont + 1;
	}

	public static int crearLlibre(Llibre llibre) {

		try {
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = null;
			try {
				dBuilder = dbFactory.newDocumentBuilder();
			} catch (ParserConfigurationException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			Document doc = dBuilder.parse(new File("Llibre.xml"));
			Element raiz = doc.getDocumentElement();

			Element llibree = doc.createElement("libro");
			
			
			String id = String.valueOf(llibre.getIdentificador());
			llibree.setAttribute("id", id);
			raiz.appendChild(llibree);
			Element titulo = doc.createElement("titulo");
			titulo.appendChild(doc.createTextNode(String.valueOf(llibre.getTitol())));
			llibree.appendChild(titulo);
			Element autor = doc.createElement("autor");
			autor.appendChild(doc.createTextNode(String.valueOf(llibre.getAutor())));
			llibree.appendChild(autor);
			Element anyoPubl = doc.createElement("anyoPubl");
			anyoPubl.appendChild(doc.createTextNode(String.valueOf(llibre.getAnyoPublicacion())));
			llibree.appendChild(anyoPubl);
			Element editorial = doc.createElement("editorial");
			editorial.appendChild(doc.createTextNode(String.valueOf(llibre.getEditorial())));
			llibree.appendChild(editorial);
			Element numPagines = doc.createElement("numPagines");
			numPagines.appendChild(doc.createTextNode(String.valueOf(llibre.getNumPagines())));
			llibree.appendChild(numPagines);

			DOMSource source = new DOMSource(doc);

			TransformerFactory transformerFactory = TransformerFactory.newInstance();

			Transformer transformer = null;

			try {

				transformer = transformerFactory.newTransformer();

				transformer.setOutputProperty(OutputKeys.INDENT, "yes");
				transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
				// initialize StreamResult with File object to save to file
				StreamResult result = new StreamResult(new StringWriter());

				try {
					transformer.transform(source, result);
				} catch (TransformerException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				// String xmlString = result.getWriter().toString();

			} catch (TransformerConfigurationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			StreamResult result = new StreamResult("Llibre.xml");

			try {

				transformer.transform(source, result);

			} catch (TransformerException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		int iD = llibre.getIdentificador();
		return iD;
	}

	public static Llibre recuperarLlibre(int id) {

		Llibre objLlibre = null;

		try {
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document document = dBuilder.parse(new File("Llibre.xml"));
			// Element raiz = document.getDocumentElement();
			// System.out.println("Contenido XML " + raiz.getNodeName() + ":");
			System.out.println("\n");
			NodeList nodeList = document.getElementsByTagName("libro");
			for (int i = 0; i < nodeList.getLength(); i++) {
				Node node = nodeList.item(i);
				Element eElement = (Element) node;
				if (node.getNodeType() == Node.ELEMENT_NODE && Integer.parseInt(eElement.getAttribute("id")) == id) {

					String idd = eElement.getAttribute("id");
					String tit = eElement.getElementsByTagName("titulo").item(0).getTextContent();
					String aut = eElement.getElementsByTagName("autor").item(0).getTextContent();
					String any = eElement.getElementsByTagName("anyoPubl").item(0).getTextContent();
					String edi = eElement.getElementsByTagName("editorial").item(0).getTextContent();
					String num = eElement.getElementsByTagName("numPagines").item(0).getTextContent();

					// creamos objeto libro
					objLlibre = new Llibre(Integer.parseInt(idd), tit, aut, Integer.parseInt(any), edi,
							Integer.parseInt(num));

				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return objLlibre;
	}

	public static void mostrarLlibre(Llibre x) {

		System.out.println("Id: " + x.getIdentificador() + "\nTitol: " + x.getTitol() + "\nAutor: " + x.getAutor()
				+ "\nEditorial: " + x.getEditorial() + "\nAny de publicacio: " + x.getAnyoPublicacion()
				+ "\nNumero de pagines: " + x.getNumPagines());
	}

	static void actualitzaLlibre(int identificador) {

		//recuperarTots().clear();
		ArrayList<Llibre> tots = recuperarTots();

		System.out.println("Id: " + identificador);
		int idd = identificador;
		System.out.println("Titol: ");
		String tit = "";
		Scanner sc1 = new Scanner(System.in);
		tit = sc1.nextLine();
		System.out.println("Autor: ");
		String aut = "";
		Scanner sc2 = new Scanner(System.in);
		aut = sc2.nextLine();
		System.out.println("Editorial: ");
		String edi = "";
		Scanner sc3 = new Scanner(System.in);
		edi = sc3.nextLine();
		System.out.println("Any de publicacio: ");
		String any = "";
		Scanner sc4 = new Scanner(System.in);
		any = sc4.nextLine();
		System.out.println("Numero de pagines: ");
		String num = "";
		Scanner sc5 = new Scanner(System.in);
		num = sc5.nextLine();

		Llibre newLlibre = new Llibre(idd, tit, aut, Integer.parseInt(any), edi, Integer.parseInt(num));

		//tots.set(identificador, newLlibre);

		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder = null;
		try {
			dBuilder = dbFactory.newDocumentBuilder();
		} catch (ParserConfigurationException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		Document doc = null;
		try {
			doc = dBuilder.parse(new File("Llibre.xml"));
		} catch (SAXException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		Element raiz = doc.getDocumentElement();
		Element llibb = doc.createElement("libros");
		
		for (Llibre ll : tots) {
			
				if(identificador==ll.getIdentificador()) {
					ll.setIdentificador		(identificador);
					ll.setAutor				(newLlibre.getAutor());
					ll.setTitol				(newLlibre.getTitol());
					ll.setAnyPublicacion	(newLlibre.getAnyoPublicacion());
					ll.setEditorial			(newLlibre.getEditorial());
					ll.setNumPagines		(newLlibre.getNumPagines());
				}

				Element llibree = doc.createElement("libro");
				llibb.appendChild(llibree);
				
				String id = String.valueOf(ll.getIdentificador());
				llibree.setAttribute("id", id);
				llibb.appendChild(llibree);
				Element titulo = doc.createElement("titulo");
				titulo.appendChild(doc.createTextNode(String.valueOf(ll.getTitol())));
				llibb.appendChild(titulo);
				Element autor = doc.createElement("autor");
				autor.appendChild(doc.createTextNode(String.valueOf(ll.getAutor())));
				llibb.appendChild(autor);
				Element anyoPubl = doc.createElement("anyoPubl");
				anyoPubl.appendChild(doc.createTextNode(String.valueOf(ll.getAnyoPublicacion())));
				llibb.appendChild(anyoPubl);
				Element editorial = doc.createElement("editorial");
				editorial.appendChild(doc.createTextNode(String.valueOf(ll.getEditorial())));
				llibb.appendChild(editorial);
				Element numPagines = doc.createElement("numPagines");
				numPagines.appendChild(doc.createTextNode(String.valueOf(ll.getNumPagines())));
				llibb.appendChild(numPagines);
		}
				DOMSource source = new DOMSource(doc);

				TransformerFactory transformerFactory = TransformerFactory.newInstance();

				Transformer transformer = null;

				try {

					transformer = transformerFactory.newTransformer();

					transformer.setOutputProperty(OutputKeys.INDENT, "yes");
					transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
					// initialize StreamResult with File object to save to file
					StreamResult result = new StreamResult(new StringWriter());

					try {
						transformer.transform(source, result);
					} catch (TransformerException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					 String xmlString = result.getWriter().toString();

				} catch (TransformerConfigurationException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				StreamResult result = new StreamResult("Llibre.xml");

				try {

					transformer.transform(source, result);

				} catch (TransformerException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}



		
	}

	
	
	
	
}
