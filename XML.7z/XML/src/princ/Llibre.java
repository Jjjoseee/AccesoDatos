package princ;

public class Llibre {

	int ident;
	String titol;
	String autor;
	int anyoPubl;
	String editorial;
	int numPagines;

	public Llibre(int id, String tit, String aut, int any, String edit, int num) {
		this.ident = id;
		this.titol = tit;
		this.autor = aut;
		this.anyoPubl = any;
		this.editorial = edit;
		this.numPagines = num;
	}
	
	//geters
	public int getIdentificador() {
		return this.ident;
	}

	public String getTitol() {
		return this.titol;
	}

	public String getAutor() {
		return this.autor;
	}

	public String getEditorial() {
		return this.editorial;
	}

	public int getAnyoPublicacion() {
		return this.anyoPubl;
	}

	public int getNumPagines() {
		return this.numPagines;
	}

	//seters
	public void setNumPagines(int i) {
		this.numPagines = i;
	}

	public void setIdentificador(int i) {
		this.ident = i;
	}

	public void setTitol(String i) {
		this.titol = i;
	}

	public void setAutor(String i) {
		this.autor = i;
	}

	public void setEditorial(String i) {
		this.editorial = i;
	}

	public void setAnyPublicacion(int i) {
		this.anyoPubl = i;
	}
}