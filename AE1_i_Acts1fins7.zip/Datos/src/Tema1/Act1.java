package Tema1;

import java.io.File;

public class Act1 {

	public static void main(String[] args) {
		String dir2 = args[0];
String ext = args[1];

		File directorio = new File(dir2);
		
		if (!directorio.exists()) {
		    System.out.println("No existe el directorio");
		}
		
		String[] lista = directorio.list();
		for (int i = 0; i < lista.length; i++) {
			System.out.println(lista[i]);
		}

	}

}
