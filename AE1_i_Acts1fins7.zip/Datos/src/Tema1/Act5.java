package Tema1;

import java.io.File;

public class Act5 {

	public static void main(String[] args) {

		String dir2 = args[0];
		File directorio = new File(dir2);

		if (args.length == 1) {
			String[] lista = directorio.list();
			for (int i = 0; i < lista.length; i++) {
				System.out.println(lista[i]);
			}
		} else {

			for (int y = 0; y < args.length; y++) {
				String[] lista = directorio.list(new FiltroExtension(args[y]));
				for (int i = 0; i < lista.length; i++) {
					System.out.println(lista[i]);
				}
			}
		}

	}

}
