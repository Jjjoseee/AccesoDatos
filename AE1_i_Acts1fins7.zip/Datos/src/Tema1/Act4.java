package Tema1;

import java.io.File;

public class Act4 {

	public static void main(String[] args) {

		String dir2 = args[0];
		File directorio = new File(dir2);
		
		if (!directorio.exists()) {
		    System.out.println("No existe el directorio");
		}else {
		    System.out.println("Existe el directorio");

		}
		
	}

}
