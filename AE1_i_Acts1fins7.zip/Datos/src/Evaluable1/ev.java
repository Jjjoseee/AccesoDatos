package Evaluable1;

import java.io.File;
import java.io.IOException;
import java.text.CharacterIterator;
import java.text.SimpleDateFormat;
import java.text.StringCharacterIterator;
import java.util.Date;
import java.util.Scanner;

import Tema1.FiltroExtension;

public class ev {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sn = new Scanner(System.in);
		int opcion;
		String dir = args[0];
		File direct = new File(dir);

		System.out.println("1. Informacio");
		System.out.println("2. Crear carpeta");
		System.out.println("3. Crear fitxer");
		System.out.println("4. Eliminar");
		System.out.println("5. Renomenar");

		System.out.println("Opcio --> ");
		opcion = sn.nextInt();

		switch (opcion) {
		case 1:
			getInformacio(direct);
			break;
		case 2:
			crearCarpeta(direct);
			break;
		case 3:
			crearFitxer(direct);
			break;
		case 4:
			eliminar(direct);
			break;
		case 5:
			renomenar(direct);
			break;
		default:
			System.out.println("Sols n�meros entre 1 i 5");
		}

	}

	public static void getInformacio(File direct) {

		int totalFicheros = 0;
		if (direct.isDirectory()) {
			System.out.println("Es un directori.");
			System.out.println("El nom es: " + direct.getName());
			System.out.println("La direccio es " + direct.getPath());

			long lastModified = direct.lastModified();
			String pattern = "yyyy-MM-dd hh:mm aa";
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
			Date lastModifiedDate = new Date(lastModified);
			System.out.println(direct + " va ser modificat: " + simpleDateFormat.format(lastModifiedDate));

			System.out.println("El contingut del directori es: ");
			String[] lista = direct.list();
			for (int i = 0; i < lista.length; i++) {
				System.out.println(lista[i]);
				totalFicheros += 1;
			}
			System.out.println("El total de ficheros es: " + totalFicheros);
			String totalSpace = convertidorBytes(direct.getTotalSpace());
			String freelSpace = convertidorBytes(direct.getFreeSpace());
			String usableSpace = convertidorBytes((direct.getTotalSpace() - direct.getUsableSpace()));

			System.out.println("Espacio total: " + totalSpace);
			System.out.println("Espacio libre: " + freelSpace);
			System.out.println("Espacio usado: " + usableSpace);

		}

		else {
			System.out.println("Es un fitxer.");
			long size = direct.length();
			System.out.println("Tamany: " + size + "bytes");

		}
	}

	public static String convertidorBytes(long bytes) {
		if (-1000 < bytes && bytes < 1000) {
			return bytes + " B";
		}
		CharacterIterator ci = new StringCharacterIterator("kMGTPE");
		while (bytes <= -999_950 || bytes >= 999_950) {
			bytes /= 1000;
			ci.next();
		}
		return String.format("%.1f %cB", bytes / 1000.0, ci.current());
	}

	public static void crearCarpeta(File direct) {
		Scanner sn = new Scanner(System.in);
		System.out.println("Nombre del directorio: ");

		String nom = direct + "/" + sn.nextLine();
		File dir = new File(nom);

		if (!dir.exists()) {
			if (dir.mkdirs()) {
				System.out.println("Directorio creado");
			} else {
				System.out.println("Error al crear directorio");
			}
		}
	}

	public static void crearFitxer(File direct) {
		Scanner sn = new Scanner(System.in);
		System.out.println("Nombre del fitxer: ");

		String nom = direct + "/" + sn.nextLine();
		File dir = new File(nom);

		if (!dir.exists()) {
			try {
				if (dir.createNewFile()) {
					System.out.println("Fitxer creado");
				} else {
					System.out.println("Error al crear fitxer");
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	public static void eliminar(File direct) {

		Scanner sn = new Scanner(System.in);
		System.out.println("Nombre del fitxer o directori a eliminar: ");

		String nom = direct + "/" + sn.nextLine();
		File dir = new File(nom);

		if (dir.isFile()) {
			if (dir.delete()) {
				System.out.println("Fitxer eliminat: " + dir.getName());
			} else {
				System.out.println("Error al eliminar el fitxer");
			}

		} else {

			if (dir.delete()) {
				System.out.println("Directori eliminat: " + dir.getName());
			} else {
				System.out.println("Error al eliminar, pot ser no est� buit.");
			}

		}
	}

	public static void renomenar(File direct) {

		Scanner sn = new Scanner(System.in);
		System.out.println("Nombre del fitxer o directori a renomenar: ");

		String nom = direct + "/" + sn.nextLine();
		File dir = new File(nom);

		if (dir.exists()) {
			System.out.println("Nou nom: ");

			String nom2 = direct + "/" + sn.nextLine();
			File dir2 = new File(nom2);

			boolean flag = dir.renameTo(dir2);

			if (flag == true) {
				System.out.println("Renomenat, de " + dir.getName() + " a " + dir2.getName());
			}

			else {
				System.out.println("Error");
			}
		} else {
			System.out.println("El directori o fitxer no existeix");
		}
	}
}
